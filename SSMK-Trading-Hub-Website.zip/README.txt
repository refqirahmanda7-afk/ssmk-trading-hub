# SSMK Trading Hub Website

Website statis gratis, terinspirasi struktur direktori bisnis seperti SloExport, tetapi desain dan kontennya dibuat khusus untuk PT SSMK TRADING HUB.

## Isi
- Hero + search
- Filter kategori
- 4 aktivitas usaha
- About company
- Ringkasan KBLI
- Contact/footer
- Responsive untuk HP

## Cara online gratis
1. Buat repository baru di GitHub.
2. Upload `index.html` dan folder `assets`.
3. Hubungkan repository ke Cloudflare Pages / GitHub Pages.
4. Deploy sebagai static site.

Tidak membutuhkan database untuk versi awal.
